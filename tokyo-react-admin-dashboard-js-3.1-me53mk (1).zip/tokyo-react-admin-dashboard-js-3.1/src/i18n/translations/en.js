const enJSON = {};

export default enJSON;
